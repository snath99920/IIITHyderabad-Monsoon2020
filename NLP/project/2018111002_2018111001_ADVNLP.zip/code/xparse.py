import xml.etree.ElementTree as ET
from sklearn.metrics import f1_score
import numpy as np
import string
from argparse import ArgumentParser
import matplotlib.pyplot as plt
import seaborn as sns

parser = ArgumentParser()
parser.add_argument("compareFile", help="Input embedding file")
args = parser.parse_args()

tree = ET.parse('data/ground-truth-training-byarticle-20181122.xml')
root = tree.getroot()
lst = []
for group in root.findall('article'):
  val = group.get('hyperpartisan')
  if val == 'true':
      lst.append(True)
  else:
      lst.append(False)
# print(len(lst))
# exit(1)
lst = lst[516:]
# print(lst)

f = open(args.compareFile,"r")
# f=open('work/elmovalid.text.tsv',"r")
# f=open('work/bertvalid.text.tsv',"r")
lines=f.readlines()
result=[]

correct_classification_prob = 0
misclassification_prob = 0
probability_list = []

for x in lines:
    prob = x.split(' ')[2]
    prob = float(prob.strip('\n'))
    # print(prob)
    val = x.split(' ')[1]
    probability_list.append(prob)
    # print(val)
    if val == 'true':
      result.append(True)
    else:
      result.append(False)
f.close()
# print(result)
y_true = np.array(lst)
y_true = 1 * y_true
# print(y_true)

y_pred = np.array(result)
y_pred = 1*y_pred
# print(y_pred)

# cnt = 0
# print(probability_list)
correct_cnt = 0
misclass_cnt = 0
for index, (first, second) in enumerate(zip(lst, result)):
    if first == second:
        correct_cnt+=1
        correct_classification_prob += probability_list[index]

        # print(index, second)
    else:
      misclass_cnt +=1
      misclassification_prob += probability_list[index]
acc = float((correct_cnt*100)/len(lst))
print(str(acc)+' %')
print(f1_score(y_true, y_pred, average='micro'))
print(correct_classification_prob/correct_cnt)
print(misclassification_prob/misclass_cnt)

##=======================================================================================================
##Below code is for Qualitative analysis only
##Uncomment to compare ELMo and SBERT overlaps
##Use Elmo tsv as input in the command line
##Needs user modification depending on the kind of plot needed by the user for comparison.

'''
f=open('work/bertvalid.text.tsv',"r")
clines=f.readlines()
bertresult = []
for x in clines:
    val = x.split(' ')[1]
    # print(val)
    if val == 'true':
      bertresult.append(True)
    else:
      bertresult.append(False)
f.close()
y_bertpred = np.array(bertresult)
y_bertpred = 1*y_bertpred

print("\n")
mismatch_count = 0
hue_list = []
mismatches_index_list = []
for index, (first, second) in enumerate(zip(y_bertpred, y_true)):
    if first != second:
        mismatch_count +=1
        mismatches_index_list.append(index)
        hue_list.append("Incorrectly classified")
        print("Mismatch index: " + str(index))
        print("Actual output: " + str(bool(y_true[index])))
        print("Elmo output: " + str(bool(first)))
        print("Bert output: " + str(bool(second)))
        print("\n")
    else:
      hue_list.append("Correctly classified")

print("Total mismatch count: " + str(mismatch_count))

f=open('work/valid.text.tsv',"r")
clines=f.readlines()
bertresult = []
articles_length_list = []
avg_length = 0
for idx, x in enumerate(clines):
  # if idx in mismatches_index_list:
      sentence = x.split(' ')[5:]
      # sencount = 0
      # numsplit = [word for word in sentence if word in ['<splt>']]
      # sencount = len(numsplit)+1
      sentence = [word for word in sentence if word not in string.punctuation]
      sentence = [word for word in sentence if word not in ['<splt>','']]
      print(len(sentence))
      avg_length += len(sentence)
      articles_length_list.append(len(sentence))
      # avg_length += sencount
      # articles_length_list.append(sencount)
f.close()
# print("Average number of words in the mismatched articles: " + str(int(avg_length/mismatch_count)))


# sns.set_theme(style="whitegrid")
# tips = sns.load_dataset("tips")
ax = sns.stripplot(x=articles_length_list,y=[""]*len(articles_length_list),hue=hue_list)

# plt.plot(articles_length_list, label='No. of words in mismatched articles')
# plt.ylabel('No. of words')
# plt.title("Classification by S-BERT")
# plt.xlabel('Number of words in the articles')
# plt.legend(loc="upper left")
# plt.savefig('bertclassify.png')
plt.show()
'''