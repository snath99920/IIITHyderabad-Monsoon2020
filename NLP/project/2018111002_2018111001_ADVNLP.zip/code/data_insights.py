import numpy as np
import string
from argparse import ArgumentParser
import matplotlib.pyplot as plt
import seaborn as sns

tot_count = 0
f=open('work/valid.text.tsv',"r")
clines=f.readlines()
articles_length_list = []
avg_length = 0
for idx, x in enumerate(clines):
    sentence = x.split(' ')[5:]
    tot_count+=1
    sencount = 0
    numsplit = [word for word in sentence if word in ['<splt>']]
    sencount = len(numsplit)+1
    sentence = [word for word in sentence if word not in string.punctuation]
    sentence = [word for word in sentence if word not in ['<splt>','']]
#   print(len(sentence))
    avg_length += sencount
    articles_length_list.append(sencount)
f.close()

f=open('work/train.text.tsv',"r")
clines=f.readlines()
for idx, x in enumerate(clines):
    sentence = x.split(' ')[5:]
    tot_count+=1
    sencount = 0
    numsplit = [word for word in sentence if word in ['<splt>']]
    sencount = len(numsplit)+1
    sentence = [word for word in sentence if word not in string.punctuation]
    sentence = [word for word in sentence if word not in ['<splt>','']]
#   print(len(sentence))
    avg_length += sencount
    articles_length_list.append(sencount)
f.close()

print("Average number of sentences in the articles: " + str(int(avg_length/tot_count)))

articles_length_list.sort()
print(articles_length_list)
# sns.set_theme(style="whitegrid")
# tips = sns.load_dataset("tips")
ax = sns.stripplot(x=articles_length_list)

# plt.plot(articles_length_list, label='No. of words in mismatched articles')
# plt.ylabel('No. of words')
plt.xlabel('Number of sentences in the articles')
# plt.legend(loc="upper left")
# plt.savefig('articles_sentences.png')
# plt.show()