#!/usr/bin/env python
'''
NOTE: This uses the alannlp PyTorch implementation of Elmo!
Process a line corpus and convert text to elmo embeddings, save as json array of sentence vectors.
This expects the sents corpus which has fields title, article, domains. and treates
title as the first sentence, then splits the article sentences. The domains are ignored
'''

import argparse
# from allennlp.commands.elmo import ElmoEmbedder
# from allennlp.modules.elmo import Elmo, batch_to_ids
import os
import json
import torch
import math
import numpy as np
from sentence_transformers import SentenceTransformer

# from sklearn.decomposition import PCA
# from sklearn.manifold import TSNE
# import chart_studio.plotly as py
# import plotly.graph_objs as go
# from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot


configs = {
  "small": "elmo_2x1024_128_2048cnn_1xhighway_options.json",
  "medium": "elmo_2x2048_256_2048cnn_1xhighway_options.json",
  "original5b": "elmo_2x4096_512_2048cnn_2xhighway_5.5B_options.json",
  "original": "elmo_2x4096_512_2048cnn_2xhighway_options.json"
}

models = {
  "small": "elmo_2x1024_128_2048cnn_1xhighway_weights.hdf5.zip",
  "medium": "elmo_2x2048_256_2048cnn_1xhighway_weights.hdf5.zip",
  "original5b": "elmo_2x4096_512_2048cnn_2xhighway_5.5B_weights.hdf5.zip",
  "original": "elmo_2x4096_512_2048cnn_2xhighway_weights.hdf5.zip"

}

if __name__ == '__main__':

    default_m = "original"
    parser = argparse.ArgumentParser()
    parser.add_argument("infile", type=str, help="Input file, should be in sent1 format")
    parser.add_argument("outfile", type=str, help="Output file, contains standard cols 0.3, plus json vectors")
    parser.add_argument("-b", type=int, default=50, help="Batchsize (50)")
    parser.add_argument("-l", type=int, default=1000, help="Log every (1000)")
    parser.add_argument("--maxtoks", type=int, default=200, help="Maximum number of tokens per sentence to use (200)")
    parser.add_argument("--maxsents", type=int, default=200, help="Maximum number of sentences per article to use (200)")
    parser.add_argument("-m", type=str, default=default_m,
                        help="Model (small, medium, original, original5b ({})".format(default_m))
    parser.add_argument("-g", action='store_true', help="Use the GPU (default: don't)")
    parser.add_argument("--concat", action='store_true', help="Concatenate representations instead of averaging")
    args = parser.parse_args()

    outfile = args.outfile
    infile = args.infile
    batchsize = args.b
    every = args.l
    use_gpu = args.g
    # model = os.path.join("elmo", models[args.m])
    # model = "elmo"
    model = SentenceTransformer('distilbert-base-nli-mean-tokens')
    config = os.path.join("elmo", configs[args.m])
    concat = args.concat
    maxtoks = args.maxtoks
    maxsents = args.maxsents

    print("Loading model {}...".format(args.m))
    if use_gpu:
        device = 0
    else:
        device = -1
    print("Processing lines...")
    with open(infile, "rt", encoding="utf8") as inp:
        nlines = 0
        with open(outfile, "wt", encoding="utf8") as outp:
            for line in inp:
                # print(line)
                # print(nlines)
                fields = line.split("\t")
                title = fields[5]
                tmp = fields[4]
                tmp = tmp.split(" <splt> ")[:maxsents]
                sents = [title]
                sents.extend(tmp)
                # now processes the sents in batches
                outs = []
                
                print(len(sents))
                mk1 = 0
                mk2 = 0
                # unlike the tensorflow version we can have dynamic batch sizes here!
                for batchnr in range(math.ceil(len(sents)/batchsize)):
                    # if nlines < 643:
                        # break
                    fromidx = batchnr * batchsize
                    mk1 = fromidx
                    toidx = (batchnr+1) * batchsize
                    actualtoidx = min(len(sents), toidx)
                    mk2 = actualtoidx
                    # print(fromidx)
                    # print("Batch: from=",fromidx,"toidx=",toidx,"actualtoidx=",actualtoidx)
                    sentsbatch = sents[fromidx:actualtoidx]
                    # sentsbatch = [s.split()[:maxtoks] for s in sentsbatch]
                    # print(sentsbatch)
                    # print(len(s))
                    sentence_embeddings = model.encode(sentsbatch)
                    # print(sentence_embeddings)
                    print(sentence_embeddings.shape)
                    outs.extend(sentence_embeddings)
                '''
                pca = PCA(n_components=50) #reduce down to 50 dim
                y = pca.fit_transform(outs)
                y = TSNE(n_components=2).fit_transform(y) # further reduce to 2 dim using t-SNE
                # print("Result lines:", len(outs))
                plotsens = sents
                # init_notebook_mode(connected=True)
                data = [
                    go.Scatter(
                        x=[i[0] for i in y],
                        y=[i[1] for i in y],
                        mode='markers',
                        text=[i for i in plotsens],
                    marker=dict(
                        size=16,
                        color = [len(i) for i in plotsens], #set color equal to a variable
                        opacity= 0.8,
                        colorscale='Viridis',
                        showscale=False
                    )
                    )
                ]
                layout = go.Layout()
                layout = dict(
                            yaxis = dict(zeroline = False),
                            xaxis = dict(zeroline = False)
                            )
                fig = go.Figure(data=data, layout=layout)
                file = plot(fig, filename='Bert_visualization.html')
                exit(1)
                '''
                outs = [a.tolist() for a in outs]
                print(fields[0], fields[1], fields[2], fields[3], json.dumps(outs), sep="\t", file=outp)
                nlines += 1
                if nlines % every == 0:
                    print("Processed lines:", nlines)
        print("Total processed lines:", nlines)
        # for i, word_list in enumerate(vocab):
        #     for j in range(len(word_list)):
        #         v_set.add(vocab[i][j])

        # for word in v_set:
        #     print(word)