#!/usr/bin/env python
'''
NOTE: This uses the alannlp PyTorch implementation of Elmo!
Process a line corpus and convert text to elmo embeddings, save as json array of sentence vectors.
This expects the sents corpus which has fields title, article, domains. and treates
title as the first sentence, then splits the article sentences. The domains are ignored
'''

import argparse
# from allennlp.commands.elmo import ElmoEmbedder
# from allennlp.modules.elmo import Elmo, batch_to_ids
# import allennlp.commands.elmo
import os
import json
import warnings  
# with warnings.catch_warnings():  
warnings.filterwarnings("ignore")
import torch
import math
import numpy as np
import tensorflow_hub as hub
import tensorflow as tf
# from pytorch_fast_elmo import FastElmo, batch_to_char_ids


configs = {
  "small": "elmo_2x1024_128_2048cnn_1xhighway_options.json",
  "medium": "elmo_2x2048_256_2048cnn_1xhighway_options.json",
  "original5b": "elmo_2x4096_512_2048cnn_2xhighway_5.5B_options.json",
  "original": "elmo_2x4096_512_2048cnn_2xhighway_options.json"
}

models = {
  "small": "elmo_2x1024_128_2048cnn_1xhighway_weights.hdf5",
  "medium": "elmo_2x2048_256_2048cnn_1xhighway_weights.hdf5",
  "original5b": "elmo_2x4096_512_2048cnn_2xhighway_5.5B_weights.hdf5",
  "original": "elmo_2x4096_512_2048cnn_2xhighway_weights.hdf5"

}

if __name__ == '__main__':

    default_m = "original"
    parser = argparse.ArgumentParser()
    parser.add_argument("infile", type=str, help="Input file, should be in sent1 format")
    parser.add_argument("outfile", type=str, help="Output file, contains standard cols 0.3, plus json vectors")
    parser.add_argument("-b", type=int, default=50, help="Batchsize (50)")
    parser.add_argument("-l", type=int, default=1000, help="Log every (1000)")
    parser.add_argument("--maxtoks", type=int, default=200, help="Maximum number of tokens per sentence to use (200)")
    parser.add_argument("--maxsents", type=int, default=200, help="Maximum number of sentences per article to use (200)")
    parser.add_argument("-m", type=str, default=default_m,
                        help="Model (small, medium, original, original5b ({})".format(default_m))
    parser.add_argument("-g", action='store_true', help="Use the GPU (default: don't)")
    parser.add_argument("--concat", action='store_true', help="Concatenate representations instead of averaging")
    args = parser.parse_args()

    outfile = args.outfile
    infile = args.infile
    batchsize = args.b
    every = args.l
    use_gpu = args.g
    model = os.path.join("elmo", models[args.m])
    config = os.path.join("elmo", configs[args.m])
    concat = args.concat
    maxtoks = args.maxtoks
    maxsents = args.maxsents

    print("Loading model {}...".format(args.m))
    if use_gpu:
        device = 0
    else:
        device = -1
    # elmo = ElmoEmbedder(options_file=config, weight_file=model, cuda_device=device)
    # elmo = Elmo(options_file=config, weight_file=model, num_output_representations=1)
    # elmo = Elmo(options_file=config, weight_file=model)
    elmo = hub.Module("https://tfhub.dev/google/elmo/3", trainable=True)
    # elmo = FastElmo(config,model)

    print("Processing lines...")
    with tf.compat.v1.Session() as sess:
        sess.run(tf.compat.v1.global_variables_initializer())
        with open(infile, "rt", encoding="utf8") as inp:
            nlines = 0
            with open(outfile, "wt", encoding="utf8") as outp:
                for line in inp:
                    # print(line)
                    print(nlines)
                    fields = line.split("\t")
                    title = fields[5]
                    tmp = fields[4]
                    tmp = tmp.split(" <splt> ")[:maxsents]
                    sents = [title]
                    sents.extend(tmp)
                    # now processes the sents in batches
                    outs = []
                    # print(sents)
                    # unlike the tensorflow version we can have dynamic batch sizes here!
                    for batchnr in range(math.ceil(len(sents)/batchsize)):
                        # if nlines < 643:
                            # break
                        fromidx = batchnr * batchsize
                        toidx = (batchnr+1) * batchsize
                        actualtoidx = min(len(sents), toidx)
                        # print(fromidx)
                        # print("Batch: from=",fromidx,"toidx=",toidx,"actualtoidx=",actualtoidx)
                        sentsbatch = sents[fromidx:actualtoidx]
                        sentsbatch = [s.split()[:maxtoks] for s in sentsbatch]
                        for s in sentsbatch:
                            if len(s) == 0:
                                s.append("")  # otherwise we get a shape (3,0,dims) result
                        # ret = elmo(batch_to_ids(sentsbatch))
                        # ret = list(elmo(sentsbatch))
                        # print(ret)
                        print(sentsbatch)
                        ret = elmo(inputs={"tokens": sentsbatch, "sequence_len": [len(sample) for sample in sentsbatch]}, signature="tokens", as_dict=True)["elmo"]
                        # print(ret)
                        # print(ret['word_emb'])
                        # print(ret['elmo'])
                        # print(ret)
                        embeddings = sess.run(ret)
                        # print(embeddings.shape)
                        embeddings = embeddings[0]
                        # print(embeddings)
                        # with tf.Session() as sess:
                        #     sess.run(tf.global_variables_initializer())
                        #     embeddings = sess.run(ret)
                        #     print(embeddings.shape)
                        #     print(embeddings)
                        
                        # the ret is the original representation of three vectors per word
                        # We first combine per word through concatenation or average, then average
                        # if concat:
                            # ret = np.concatenate(embeddings, axis=1)
                            # ret = [np.concatenate(x, axis=1) for x in embeddings]
                        # else:
                            # print(ret)
                            # print(type(ret))
                            # avg_embeds = []
                            # for embd, mask in zip(ret['elmo_representations'][0], ret['mask']):
                            #     # print(embd)
                            #     # print(mask)
                            #     avg_embeds.append((torch.sum(embd, dim=0) / torch.sum(mask)).detach().numpy())
                            # print(avg_embeds)
                            # print("OK")
                            # ret = [torch.sum(x, dim=1).detach().numpy() for x in ret['elmo_representations'][0]]
                            # ret = [np.average(x, axis=1) for x in embeddings]
                            # ret = np.average(embeddings, axis=1)
                            # print(ret.shape)
                        # print("DEBUG tmpembs=", [l.shape for l in tmpembs])
                        # ret = np.average(ret, axis=0)
                        # print(len(ret))
                        # print(ret.shape)
                        # print(embeddings)
                        embeddings = np.average(embeddings, axis=0)
                        print(embeddings.shape)
                        # print(type(embeddings))
                        # exit(1)
                        # print("DEBUG finalreps=", [l.shape for l in finalreps])
                        outs.append(embeddings)

                    # print("Result lines:", len(outs))
                    outs = [a.tolist() for a in outs]
                    print(fields[0], fields[1], fields[2], fields[3], json.dumps(outs), sep="\t", file=outp)
                    nlines += 1
                    if nlines % every == 0:
                        print("Processed lines:", nlines)
            print("Total processed lines:", nlines)
