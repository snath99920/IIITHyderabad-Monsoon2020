#!/bin/bash

inbert="$1"
outpreds="$2"

if [[ "x$outpreds" == "x" ]]
then
  echo Need two parameters, input bert embeddings file and output predictions file
  exit 1
fi

models=`find bert_saved_models/ -name '*.hdf5' | sort -r | head -3`
amodels=($models)
m1=${amodels[0]}
m2=${amodels[1]}
m3=${amodels[2]}

echo 'Running: ' python3 bert_ensemble_pred.py --saved_model1 $m1 --saved_model2 $m2 --saved_model3 $m3 --inputTSV $inbert --output $outpreds
# python3 ensemble_pred.py --saved_model1 $m1 --saved_model2 $m2 --saved_model3 $m3 --inputTSV $inbert --output $outpreds
KERAS_BACKEND=tensorflow python3 bert_ensemble_pred.py --saved_model1 $m1 --saved_model2 $m2 --saved_model3 $m3 --inputTSV $inbert --output $outpreds

