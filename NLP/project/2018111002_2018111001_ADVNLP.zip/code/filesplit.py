import sys

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

def writeToFile(file_name, file_array):
    with open(file_name,'w') as handle:
        for i in file_array:
            handle.write(i)
            handle.write("\n")

data_path = 'work/'

filename = sys.argv[1]

filelength = file_len(filename)


train_split_pt = int(0.8 * filelength)
valid_split_pt = int(filelength)

x = open(filename).read().splitlines()

train_file = data_path + 'train.bert.tsv'
valid_file = data_path + 'valid.bert.tsv'
# test_file = split_path + 'test/' + lang + '_test.txt'

writeToFile(train_file, x[:train_split_pt])
writeToFile(valid_file, x[train_split_pt:valid_split_pt])
# writeToFile(test_file, x[valid_split_pt:]