The work is done in jupyter notebook

Running:
**Bash**
``jupyter notebook``

execute the code cell-wise