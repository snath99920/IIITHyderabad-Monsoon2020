const Vickrey = artifacts.require("Vickrey");

module.exports = function (deployer) {
  deployer.deploy(Vickrey);
};
